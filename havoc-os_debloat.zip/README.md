# Havoc-OS debloat script

I like [Havoc-OS](https://sourceforge.net/projects/havoc-os/) but it have some apps what i not use at all, so this module disable this apps.

For now in list:
* AntHalService
* EasterEgg
* FM2
* Browser
* Stk
* PrintSpooler
* BuiltInPrintService
* LiveWallpapersPicker
* Snap
* CellBroadcastReceiver


