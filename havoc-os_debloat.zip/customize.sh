REPLACE="
/system/app/AntHalService
/system/app/EasterEgg
/system/app/FM2
/system/app/Browser
/system/app/Stk
/system/app/PrintSpooler
/system/app/BuiltInPrintService
/system/app/LiveWallpapersPicker
/system/priv-app/Snap
/system/priv-app/CellBroadcastReceiver
"

